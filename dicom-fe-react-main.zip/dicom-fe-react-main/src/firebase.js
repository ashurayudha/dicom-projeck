import { initializeApp } from "firebase/app";
const firebaseConfig = {
  apiKey: "AIzaSyDgE5qmW1ayYdakqSfRQj7d3XQ8rbfkwDA",
  authDomain: "dev-dicomdisty.firebaseapp.com",
  projectId: "dev-dicomdisty",
  storageBucket: "dev-dicomdisty.appspot.com",
  messagingSenderId: "704358638141",
  appId: "1:704358638141:web:5b3d306cdda0bc83660054"
};

const app = initializeApp(firebaseConfig);